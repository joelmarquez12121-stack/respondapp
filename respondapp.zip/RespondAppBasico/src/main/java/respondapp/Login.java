package respondapp;

import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {


    public Login() {
        initComponents();
        setLocationRelativeTo(null);
        getRootPane().setDefaultButton(btnEntrar);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();
        btnEntrar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("RespondApp - Ingresar");
        setPreferredSize(new java.awt.Dimension(460, 290));
        setResizable(false);
        getContentPane().setLayout(null);

        lblTitulo.setText("RespondApp - Preguntas y respuestas");
        getContentPane().add(lblTitulo);
        lblTitulo.setBounds(25, 20, 400, 25);

        lblUsuario.setText("Usuario");
        getContentPane().add(lblUsuario);
        lblUsuario.setBounds(25, 65, 120, 25);
        getContentPane().add(txtUsuario);
        txtUsuario.setBounds(150, 65, 260, 28);

        lblClave.setText("Clave");
        getContentPane().add(lblClave);
        lblClave.setBounds(25, 110, 120, 25);
        getContentPane().add(txtClave);
        txtClave.setBounds(150, 110, 260, 28);

        btnEntrar.setText("Ingresar");
        btnEntrar.addActionListener(this::btnEntrarActionPerformed);
        getContentPane().add(btnEntrar);
        btnEntrar.setBounds(150, 160, 125, 32);

        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);
        getContentPane().add(btnSalir);
        btnSalir.setBounds(285, 160, 125, 32);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
        char[] clave=txtClave.getPassword();
        try {
            Usuario sesion=Datos.entrar(txtUsuario.getText(),clave);
            new Menu(sesion).setVisible(true); dispose();
        } catch(Exception ex) { Pantalla.error(this,ex); }
        finally { java.util.Arrays.fill(clave,'\0'); txtClave.setText(""); }
    }//GEN-LAST:event_btnEntrarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() { new Login().setVisible(true); }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
