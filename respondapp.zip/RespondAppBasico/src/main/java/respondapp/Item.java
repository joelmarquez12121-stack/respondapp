package respondapp;

// Un combo muestra el nombre, pero conserva el id para las claves foraneas.
public class Item {
    public int id;
    public String texto;
    public Item(int id, String texto) { this.id = id; this.texto = texto; }
    @Override public String toString() { return texto; }
}
