package respondapp;

import javax.swing.JOptionPane;

public class Consultas extends javax.swing.JFrame {
    private Usuario sesion;

    public Consultas(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion; txtPartida.setText("1");
        try { Datos.administrador(sesion); for(Item i:Datos.jugadores()) cmbJugador.addItem(i); } catch(Exception ex) { Pantalla.error(this,ex); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblConsulta = new javax.swing.JLabel();
        cmbConsulta = new javax.swing.JComboBox();
        lblPartida = new javax.swing.JLabel();
        txtPartida = new javax.swing.JTextField();
        lblJugador = new javax.swing.JLabel();
        cmbJugador = new javax.swing.JComboBox();
        btnEjecutar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        tblConsulta = new javax.swing.JTable();
        scrolltblConsulta = new javax.swing.JScrollPane();
        lblAyuda = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Seis consultas");
        setResizable(false);
        setPreferredSize(new java.awt.Dimension(840, 550));
        getContentPane().setLayout(null);
        lblConsulta.setText("Consulta");
        getContentPane().add(lblConsulta);
        lblConsulta.setBounds(25, 20, 160, 25);
        cmbConsulta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"1 - Preguntas dificiles de Deportes", "2 - Duracion de una partida finalizada", "3 - Puntos historicos de un jugador", "4 - Rondas con preguntas faciles", "5 - Meses con mayor frecuencia de partidas", "6 - Jugadores con mas juegos"}));
        getContentPane().add(cmbConsulta);
        cmbConsulta.setBounds(190, 20, 570, 28);
        lblPartida.setText("ID de partida (consulta 2)");
        getContentPane().add(lblPartida);
        lblPartida.setBounds(25, 65, 160, 25);
        getContentPane().add(txtPartida);
        txtPartida.setBounds(190, 65, 570, 28);
        lblJugador.setText("Jugador (consulta 3)");
        getContentPane().add(lblJugador);
        lblJugador.setBounds(25, 105, 160, 25);
        getContentPane().add(cmbJugador);
        cmbJugador.setBounds(190, 105, 570, 28);
        btnEjecutar.setText("Ejecutar consulta");
        btnEjecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEjecutarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEjecutar);
        btnEjecutar.setBounds(190, 150, 200, 32);
        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(410, 150, 150, 32);
        scrolltblConsulta.setViewportView(tblConsulta);
        tblConsulta.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        getContentPane().add(scrolltblConsulta);
        scrolltblConsulta.setBounds(25, 210, 735, 235);
        lblAyuda.setText("Consulta 4: se interpreta la dificultad de la pregunta de cada ronda.");
        getContentPane().add(lblAyuda);
        lblAyuda.setBounds(25, 460, 760, 25);
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEjecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEjecutarActionPerformed
        try {
            int numero=cmbConsulta.getSelectedIndex(),parametro=0;
            if(numero==1) {
                try { parametro=Integer.parseInt(txtPartida.getText().trim()); if(parametro<1) throw new NumberFormatException(); }
                catch(NumberFormatException ex) { throw new Exception("Ingrese un ID de partida positivo."); }
            }
            if(numero==2) parametro=Pantalla.id(cmbJugador);
            tblConsulta.setModel(Datos.consulta(sesion,numero,parametro));
            if(tblConsulta.getRowCount()==0) JOptionPane.showMessageDialog(this,"No hay resultados para esa seleccion.");
        } catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnEjecutarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblConsulta;
    private javax.swing.JComboBox<String> cmbConsulta;
    private javax.swing.JLabel lblPartida;
    private javax.swing.JTextField txtPartida;
    private javax.swing.JLabel lblJugador;
    private javax.swing.JComboBox<Item> cmbJugador;
    private javax.swing.JButton btnEjecutar;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JTable tblConsulta;
    private javax.swing.JScrollPane scrolltblConsulta;
    private javax.swing.JLabel lblAyuda;
    // End of variables declaration//GEN-END:variables
}
