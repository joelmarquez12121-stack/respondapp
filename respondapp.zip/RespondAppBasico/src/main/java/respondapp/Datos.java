package respondapp;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

// SQL de la aplicacion. No hay frameworks, interfaces DAO ni capas adicionales.
public class Datos {
    public static void administrador(Usuario sesion) throws Exception {
        if (sesion == null || !sesion.esAdmin()) throw new Exception("Esta accion requiere un administrador.");
    }
    public static void jugador(Usuario sesion) throws Exception {
        if (sesion == null || !"JUGADOR".equals(sesion.rol)) throw new Exception("Esta accion requiere un jugador.");
    }
    private static Usuario leerUsuario(ResultSet rs) throws Exception {
        Usuario u = new Usuario();
        u.id = rs.getInt("id_usuario");
        u.nombre = rs.getString("nombre_completo");
        u.usuario = rs.getString("nombre_usuario");
        u.nacimiento = rs.getString("fecha_nacimiento");
        u.email = rs.getString("email");
        u.rol = rs.getString("rol");
        return u;
    }
    public static Usuario entrar(String nombre, char[] clave) throws Exception {
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement("SELECT * FROM usuario WHERE nombre_usuario=?")) {
            ps.setString(1, nombre.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && Clave.verificar(clave, rs.getString("clave"))) return leerUsuario(rs);
            }
        }
        throw new Exception("Usuario o clave incorrectos.");
    }
    public static void crearUsuario(Usuario sesion, String nombre, String usuario, String fecha, String email, char[] clave, String rol) throws Exception {
        administrador(sesion);
        nombre = Validar.texto(nombre, "Nombre completo", 100);
        usuario = Validar.texto(usuario, "Usuario", 40);
        if (!usuario.matches("[a-zA-Z0-9_]{3,40}")) throw new Exception("Usuario: use de 3 a 40 letras, numeros o guion bajo.");
        fecha = Validar.fecha(fecha); email = Validar.email(email); Validar.clave(clave);
        if (!"JUGADOR".equals(rol) && !"ADMINISTRADOR".equals(rol)) throw new Exception("Rol invalido.");
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement("INSERT INTO usuario(nombre_completo,nombre_usuario,fecha_nacimiento,email,clave,rol) VALUES(?,?,?,?,?,?)")) {
            ps.setString(1, nombre); ps.setString(2, usuario); ps.setString(3, fecha); ps.setString(4, email); ps.setString(5, Clave.guardar(clave)); ps.setString(6, rol); ps.executeUpdate();
        }
    }
    public static void perfil(Usuario sesion, String nombre, String fecha, String email) throws Exception {
        jugador(sesion);
        nombre = Validar.texto(nombre, "Nombre completo", 100); fecha = Validar.fecha(fecha); email = Validar.email(email);
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement("UPDATE usuario SET nombre_completo=?,fecha_nacimiento=?,email=? WHERE id_usuario=?")) {
            ps.setString(1,nombre); ps.setString(2,fecha); ps.setString(3,email); ps.setInt(4,sesion.id); ps.executeUpdate();
        }
        sesion.nombre=nombre; sesion.nacimiento=fecha; sesion.email=email;
    }
    public static ArrayList<Item> categorias() throws Exception {
        ArrayList<Item> lista = new ArrayList<>();
        try (Connection c = Conexion.abrir(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id_categoria,nombre FROM categoria ORDER BY nombre")) {
            while (rs.next()) lista.add(new Item(rs.getInt(1),rs.getString(2)));
        }
        return lista;
    }
    public static ArrayList<Item> jugadores() throws Exception {
        ArrayList<Item> lista = new ArrayList<>();
        try (Connection c = Conexion.abrir(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id_usuario,nombre_usuario FROM usuario WHERE rol='JUGADOR' ORDER BY nombre_usuario")) {
            while (rs.next()) lista.add(new Item(rs.getInt(1),rs.getString(2)));
        }
        return lista;
    }
    public static void categoriaGuardar(Usuario sesion, int id, String nombre, String descripcion) throws Exception {
        administrador(sesion); nombre=Validar.texto(nombre,"Nombre",60); descripcion=Validar.texto(descripcion,"Descripcion",250);
        String sql = id==0 ? "INSERT INTO categoria(nombre,descripcion) VALUES(?,?)" : "UPDATE categoria SET nombre=?,descripcion=? WHERE id_categoria=?";
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1,nombre); ps.setString(2,descripcion); if (id!=0) ps.setInt(3,id); ps.executeUpdate();
        }
    }
    public static void categoriaEliminar(Usuario sesion, int id) throws Exception {
        administrador(sesion);
        if (id==0) throw new Exception("Seleccione una categoria de la tabla.");
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement("DELETE FROM categoria WHERE id_categoria=?")) {
            ps.setInt(1,id); ps.executeUpdate();
        }
    }
    public static DefaultTableModel tabla(String sql, Object... valores) throws Exception {
        DefaultTableModel modelo = new DefaultTableModel() {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
        try (Connection c = Conexion.abrir(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i=0; i<valores.length; i++) ps.setObject(i+1,valores[i]);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta=rs.getMetaData(); int columnas=meta.getColumnCount();
                for (int i=1; i<=columnas; i++) modelo.addColumn(meta.getColumnLabel(i));
                while (rs.next()) { Object[] fila=new Object[columnas]; for (int i=0;i<columnas;i++) fila[i]=rs.getObject(i+1); modelo.addRow(fila); }
            }
        }
        return modelo;
    }
    public static DefaultTableModel usuariosTabla(Usuario sesion) throws Exception {
        administrador(sesion);
        return tabla("SELECT id_usuario AS ID,nombre_usuario AS Usuario,nombre_completo AS Nombre,rol AS Rol FROM usuario ORDER BY id_usuario");
    }
    public static DefaultTableModel categoriasTabla(Usuario sesion) throws Exception {
        administrador(sesion); return tabla("SELECT id_categoria AS ID,nombre AS Nombre,descripcion AS Descripcion FROM categoria ORDER BY nombre");
    }
    public static DefaultTableModel preguntasTabla(Usuario sesion) throws Exception {
        administrador(sesion); return tabla("SELECT p.id_pregunta AS ID,c.nombre AS Categoria,p.dificultad AS Dificultad,p.texto AS Pregunta FROM pregunta p JOIN categoria c ON c.id_categoria=p.id_categoria ORDER BY p.id_pregunta");
    }
    public static class PreguntaDatos {
        public int id, categoria;
        public String texto, dificultad, correcta;
        public int[] opcionesId = new int[4];
        public String[] opciones = new String[4];
    }
    private static PreguntaDatos leerPregunta(Connection c, int id) throws Exception {
        PreguntaDatos p=new PreguntaDatos(); p.id=id;
        try (PreparedStatement ps=c.prepareStatement("SELECT * FROM pregunta WHERE id_pregunta=?")) {
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()) {
                if (!rs.next()) throw new Exception("La pregunta ya no existe.");
                p.categoria=rs.getInt("id_categoria"); p.texto=rs.getString("texto"); p.dificultad=rs.getString("dificultad"); p.correcta=rs.getString("respuesta_correcta");
            }
        }
        try (PreparedStatement ps=c.prepareStatement("SELECT id_opcion,texto FROM opcion WHERE id_pregunta=? ORDER BY numero")) {
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()) {
                int i=0; while(rs.next() && i<4) { p.opcionesId[i]=rs.getInt(1); p.opciones[i]=rs.getString(2); i++; }
                if (i!=4) throw new Exception("La pregunta debe tener exactamente cuatro opciones.");
            }
        }
        return p;
    }
    public static PreguntaDatos preguntaLeer(Usuario sesion,int id) throws Exception {
        administrador(sesion); try(Connection c=Conexion.abrir()) { return leerPregunta(c,id); }
    }
    public static void preguntaGuardar(Usuario sesion,int id,int categoria,String texto,String dificultad,String[] opciones,int correcta) throws Exception {
        administrador(sesion); texto=Validar.texto(texto,"Pregunta",500);
        if (opciones.length!=4 || correcta<0 || correcta>3) throw new Exception("Indique cuatro opciones y una correcta.");
        if (!dificultad.equals("facil") && !dificultad.equals("medio") && !dificultad.equals("dificil")) throw new Exception("Dificultad invalida.");
        for (int i=0;i<4;i++) {
            opciones[i]=Validar.texto(opciones[i],"Opcion "+(i+1),250);
            for (int j=0;j<i;j++) if(opciones[i].equalsIgnoreCase(opciones[j])) throw new Exception("Las cuatro opciones deben ser distintas.");
        }
        try(Connection c=Conexion.abrir()) {
            c.setAutoCommit(false);
            try {
                String sql=id==0 ? "INSERT INTO pregunta(id_categoria,texto,respuesta_correcta,dificultad) VALUES(?,?,?,?)" : "UPDATE pregunta SET id_categoria=?,texto=?,respuesta_correcta=?,dificultad=? WHERE id_pregunta=?";
                try(PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1,categoria); ps.setString(2,texto); ps.setString(3,opciones[correcta]); ps.setString(4,dificultad);
                    if(id!=0) ps.setInt(5,id);
                    if(ps.executeUpdate()!=1) throw new Exception("No se pudo guardar la pregunta.");
                    if(id==0) try(ResultSet rs=ps.getGeneratedKeys()) { rs.next(); id=rs.getInt(1); }
                }
                try(PreparedStatement ps=c.prepareStatement("DELETE FROM opcion WHERE id_pregunta=?")) { ps.setInt(1,id); ps.executeUpdate(); }
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO opcion(id_pregunta,numero,texto) VALUES(?,?,?)")) {
                    for(int i=0;i<4;i++) { ps.setInt(1,id); ps.setInt(2,i+1); ps.setString(3,opciones[i]); ps.executeUpdate(); }
                }
                c.commit();
            } catch(Exception ex) { c.rollback(); throw ex; }
        }
    }
    public static int nuevaPartida(Usuario sesion,int otro,char[] claveOtro,int rondas) throws Exception {
        jugador(sesion);
        if(otro==sesion.id) throw new Exception("Seleccione dos jugadores distintos.");
        if(rondas<2 || rondas>20 || rondas%2!=0) throw new Exception("Use un numero par de rondas entre 2 y 20.");
        try(Connection c=Conexion.abrir()) {
            try(PreparedStatement ps=c.prepareStatement("SELECT nombre_usuario FROM usuario WHERE id_usuario=? AND rol='JUGADOR'")) {
                ps.setInt(1,otro); try(ResultSet rs=ps.executeQuery()) {
                    if(!rs.next()) throw new Exception("Segundo jugador invalido.");
                    entrar(rs.getString(1),claveOtro);
                }
            }
            try(Statement st=c.createStatement();ResultSet rs=st.executeQuery("SELECT COUNT(*) FROM pregunta p WHERE (SELECT COUNT(*) FROM opcion o WHERE o.id_pregunta=p.id_pregunta)=4")) {
                rs.next(); if(rs.getInt(1)<rondas) throw new Exception("No hay suficientes preguntas. Cargue mas o elija menos rondas.");
            }
            try(PreparedStatement ps=c.prepareStatement("INSERT INTO partida(id_jugador1,id_jugador2,id_jugador_activo,fecha,hora_comienzo,hora_actual,inicio,estado,total_rondas) VALUES(?,?,?,CURDATE(),CURTIME(),CURTIME(),NOW(),'en curso',?)",Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1,sesion.id); ps.setInt(2,otro); ps.setInt(3,sesion.id); ps.setInt(4,rondas); ps.executeUpdate();
                try(ResultSet rs=ps.getGeneratedKeys()) { rs.next(); return rs.getInt(1); }
            }
        }
    }
    public static ArrayList<Item> pendientes(Usuario sesion) throws Exception {
        jugador(sesion); ArrayList<Item> lista=new ArrayList<>();
        try(Connection c=Conexion.abrir();PreparedStatement ps=c.prepareStatement("SELECT p.id_partida,u.nombre_usuario,v.nombre_usuario FROM partida p JOIN usuario u ON u.id_usuario=p.id_jugador1 JOIN usuario v ON v.id_usuario=p.id_jugador2 WHERE p.estado='en curso' AND (p.id_jugador1=? OR p.id_jugador2=?) ORDER BY p.id_partida")) {
            ps.setInt(1,sesion.id); ps.setInt(2,sesion.id); try(ResultSet rs=ps.executeQuery()) { while(rs.next()) lista.add(new Item(rs.getInt(1),"Partida "+rs.getInt(1)+": "+rs.getString(2)+" / "+rs.getString(3))); }
        }
        return lista;
    }
    public static class Estado {
        public int id, jugador1, jugador2, activo, respondidas, total, puntos1, puntos2;
        public String nombre1,nombre2,estado;
    }
    private static Estado estado(Connection c,Usuario sesion,int id,boolean bloquear) throws Exception {
        jugador(sesion); Estado e=new Estado(); e.id=id;
        try(PreparedStatement ps=c.prepareStatement("SELECT p.*,u.nombre_usuario AS nombre1,v.nombre_usuario AS nombre2 FROM partida p JOIN usuario u ON u.id_usuario=p.id_jugador1 JOIN usuario v ON v.id_usuario=p.id_jugador2 WHERE p.id_partida=?"+(bloquear ? " FOR UPDATE" : ""))) {
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()) {
                if(!rs.next()) throw new Exception("Partida inexistente.");
                e.jugador1=rs.getInt("id_jugador1"); e.jugador2=rs.getInt("id_jugador2"); e.activo=rs.getInt("id_jugador_activo");
                if(sesion.id!=e.jugador1 && sesion.id!=e.jugador2) throw new Exception("No participa en esta partida.");
                e.total=rs.getInt("total_rondas"); e.estado=rs.getString("estado"); e.nombre1=rs.getString("nombre1"); e.nombre2=rs.getString("nombre2");
            }
        }
        try(PreparedStatement ps=c.prepareStatement("SELECT id_jugador,COUNT(*),SUM(puntos) FROM ronda WHERE id_partida=? GROUP BY id_jugador")) {
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()) { while(rs.next()) { e.respondidas+=rs.getInt(2); if(rs.getInt(1)==e.jugador1) e.puntos1=rs.getInt(3); else e.puntos2=rs.getInt(3); } }
        }
        return e;
    }
    public static Estado estado(Usuario sesion,int id) throws Exception {
        try(Connection c=Conexion.abrir()) { return estado(c,sesion,id,false); }
    }
    public static PreguntaDatos sortear(Usuario sesion,int partida,int categoria) throws Exception {
        try(Connection c=Conexion.abrir()) {
            Estado e=estado(c,sesion,partida,false);
            if(!e.estado.equals("en curso")) throw new Exception("La partida ya finalizo.");
            try(PreparedStatement ps=c.prepareStatement("SELECT p.id_pregunta FROM pregunta p WHERE p.id_categoria=? AND (SELECT COUNT(*) FROM opcion o WHERE o.id_pregunta=p.id_pregunta)=4 AND NOT EXISTS(SELECT 1 FROM ronda r WHERE r.id_partida=? AND r.id_pregunta=p.id_pregunta) ORDER BY RAND() LIMIT 1")) {
                ps.setInt(1,categoria); ps.setInt(2,partida); try(ResultSet rs=ps.executeQuery()) {
                    if(!rs.next()) throw new Exception("No quedan preguntas de esta categoria en la partida. Elija otra categoria.");
                    return leerPregunta(c,rs.getInt(1));
                }
            }
        }
    }
    // Respuesta + puntos + cambio de turno + ranking se confirman juntos.
    public static String responder(Usuario sesion,int partida,int numero,int pregunta,int opcion) throws Exception {
        try(Connection c=Conexion.abrir()) {
            c.setAutoCommit(false);
            try {
                Estado e=estado(c,sesion,partida,true);
                if(!e.estado.equals("en curso") || numero!=e.respondidas+1) throw new Exception("La ronda ya se registro. Vuelva a abrir la partida.");
                PreguntaDatos p=leerPregunta(c,pregunta);
                String dada=null;
                for(int i=0;i<4;i++) if(p.opcionesId[i]==opcion) dada=p.opciones[i];
                if(dada==null) throw new Exception("La opcion cambio o no pertenece a esta pregunta. Cargue de nuevo la pregunta.");
                boolean acierto=dada.equals(p.correcta); int puntos=acierto ? 10 : 0;
                // Bloquear categoria serializa las actualizaciones de su ranking.
                try(PreparedStatement ps=c.prepareStatement("SELECT id_categoria FROM categoria WHERE id_categoria=? FOR UPDATE")) { ps.setInt(1,p.categoria); try(ResultSet rs=ps.executeQuery()) { rs.next(); } }
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO ronda(id_partida,numero,id_jugador,id_pregunta,id_categoria,respuesta_dada,respuesta_correcta,acierto,dificultad,puntos) VALUES(?,?,?,?,?,?,?,?,?,?)")) {
                    ps.setInt(1,partida); ps.setInt(2,numero); ps.setInt(3,e.activo); ps.setInt(4,p.id); ps.setInt(5,p.categoria); ps.setString(6,dada); ps.setString(7,p.correcta); ps.setString(8,acierto ? "SI":"NO"); ps.setString(9,p.dificultad); ps.setInt(10,puntos); ps.executeUpdate();
                }
                boolean fin=numero==e.total;
                try(PreparedStatement ps=c.prepareStatement("UPDATE partida SET id_jugador_activo=?,hora_actual=CURTIME(),estado=?,hora_finalizacion=IF(?,CURTIME(),NULL),fin=IF(?,NOW(),NULL) WHERE id_partida=?")) {
                    ps.setInt(1,e.activo==e.jugador1 ? e.jugador2:e.jugador1); ps.setString(2,fin ? "finalizada":"en curso"); ps.setBoolean(3,fin); ps.setBoolean(4,fin); ps.setInt(5,partida); ps.executeUpdate();
                }
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO ranking(id_usuario,id_categoria,puntos,posicion) VALUES(?,?,?,1) ON DUPLICATE KEY UPDATE puntos=puntos+?")) {
                    ps.setInt(1,e.activo); ps.setInt(2,p.categoria); ps.setInt(3,puntos); ps.setInt(4,puntos); ps.executeUpdate();
                }
                recalcularPosiciones(c,p.categoria);
                c.commit();
                return acierto ? "Respuesta correcta. +10 puntos." : "Respuesta incorrecta. +0 puntos. Correcta: "+p.correcta;
            } catch(Exception ex) { c.rollback(); throw ex; }
        }
    }
    private static void recalcularPosiciones(Connection c,int categoria) throws Exception {
        ArrayList<int[]> filas=new ArrayList<>();
        try(PreparedStatement ps=c.prepareStatement("SELECT id_ranking,puntos FROM ranking WHERE id_categoria=? ORDER BY puntos DESC,id_usuario")) {
            ps.setInt(1,categoria); try(ResultSet rs=ps.executeQuery()) { while(rs.next()) filas.add(new int[]{rs.getInt(1),rs.getInt(2)}); }
        }
        int puesto=0,anterior=-1;
        try(PreparedStatement ps=c.prepareStatement("UPDATE ranking SET posicion=? WHERE id_ranking=?")) {
            for(int i=0;i<filas.size();i++) {
                int[] fila=filas.get(i); if(fila[1]!=anterior) puesto=i+1; anterior=fila[1];
                ps.setInt(1,puesto); ps.setInt(2,fila[0]); ps.executeUpdate();
            }
        }
    }
    public static DefaultTableModel ranking(Usuario sesion,int categoria,boolean soloMio) throws Exception {
        if(sesion==null) throw new Exception("Inicie sesion.");
        String sql="SELECT r.posicion AS Posicion,u.nombre_usuario AS Jugador,r.puntos AS Puntos FROM ranking r JOIN usuario u ON u.id_usuario=r.id_usuario WHERE r.id_categoria=?";
        if(soloMio) return tabla(sql+" AND r.id_usuario=? ORDER BY r.posicion,u.nombre_usuario",categoria,sesion.id);
        return tabla(sql+" ORDER BY r.posicion,u.nombre_usuario",categoria);
    }
    public static DefaultTableModel consulta(Usuario sesion,int numero,int parametro) throws Exception {
        administrador(sesion);
        switch(numero) {
            case 0: return tabla("SELECT COUNT(*) AS Preguntas_dificiles_de_deportes FROM pregunta p JOIN categoria c ON c.id_categoria=p.id_categoria WHERE LOWER(c.nombre)='deportes' AND p.dificultad='dificil'");
            case 1: return tabla("SELECT id_partida AS Partida,ROUND(TIMESTAMPDIFF(SECOND,inicio,fin)/60.0,2) AS Minutos FROM partida WHERE estado='finalizada' AND id_partida=?",parametro);
            case 2: return tabla("SELECT u.nombre_usuario AS Jugador,COALESCE(SUM(r.puntos),0) AS Puntos_historial FROM usuario u LEFT JOIN ronda r ON r.id_jugador=u.id_usuario WHERE u.rol='JUGADOR' AND u.id_usuario=? GROUP BY u.id_usuario,u.nombre_usuario",parametro);
            case 3: return tabla("SELECT COUNT(*) AS Rondas_con_preguntas_faciles FROM ronda WHERE dificultad='facil'");
            case 4: return tabla("SELECT DATE_FORMAT(inicio,'%Y-%m') AS Periodo,COUNT(*) AS Partidas FROM partida GROUP BY DATE_FORMAT(inicio,'%Y-%m') ORDER BY Partidas DESC,Periodo");
            case 5: return tabla("SELECT u.nombre_usuario AS Jugador,COUNT(p.id_partida) AS Juegos FROM usuario u LEFT JOIN partida p ON u.id_usuario=p.id_jugador1 OR u.id_usuario=p.id_jugador2 WHERE u.rol='JUGADOR' GROUP BY u.id_usuario,u.nombre_usuario ORDER BY Juegos DESC,Jugador");
            default: throw new Exception("Consulta invalida.");
        }
    }
}
