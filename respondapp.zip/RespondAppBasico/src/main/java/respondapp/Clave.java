package respondapp;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// Esta clase solo se ocupa de guardar/verificar contrasenas, no de las pantallas.
public class Clave {
    private static byte[] calcular(char[] clave, byte[] sal) throws Exception {
        PBEKeySpec datos = new PBEKeySpec(clave, sal, 120000, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(datos).getEncoded();
        } finally { datos.clearPassword(); }
    }
    public static String guardar(char[] clave) throws Exception {
        byte[] sal = new byte[16];
        new SecureRandom().nextBytes(sal);
        return Base64.getEncoder().encodeToString(sal) + ":" + Base64.getEncoder().encodeToString(calcular(clave, sal));
    }
    public static boolean verificar(char[] clave, String guardada) throws Exception {
        String[] partes = guardada.split(":");
        if (partes.length != 2) return false;
        return MessageDigest.isEqual(calcular(clave, Base64.getDecoder().decode(partes[0])), Base64.getDecoder().decode(partes[1]));
    }
}
