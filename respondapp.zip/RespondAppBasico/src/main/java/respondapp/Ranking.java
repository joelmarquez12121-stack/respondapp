package respondapp;

import javax.swing.JOptionPane;

public class Ranking extends javax.swing.JFrame {
    private Usuario sesion;

    public Ranking(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        try { for(Item i:Datos.categorias()) cmbCategoria.addItem(i); } catch(Exception ex) { Pantalla.error(this,ex); }
        chkMio.setEnabled(!sesion.esAdmin());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblCategoria = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        chkMio = new javax.swing.JCheckBox();
        btnVer = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        scrolltblRanking = new javax.swing.JScrollPane();
        tblRanking = new javax.swing.JTable();
        lblAyuda = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Ranking");
        setPreferredSize(new java.awt.Dimension(670, 490));
        setResizable(false);
        getContentPane().setLayout(null);

        lblCategoria.setText("Categoria");
        getContentPane().add(lblCategoria);
        lblCategoria.setBounds(25, 25, 160, 25);
        getContentPane().add(cmbCategoria);
        cmbCategoria.setBounds(190, 25, 400, 28);

        chkMio.setText("Ver solo mi posicion");
        getContentPane().add(chkMio);
        chkMio.setBounds(25, 70, 250, 28);

        btnVer.setText("Consultar");
        btnVer.addActionListener(this::btnVerActionPerformed);
        getContentPane().add(btnVer);
        btnVer.setBounds(300, 68, 140, 32);

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(455, 68, 140, 32);

        tblRanking.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrolltblRanking.setViewportView(tblRanking);

        getContentPane().add(scrolltblRanking);
        scrolltblRanking.setBounds(25, 125, 580, 245);

        lblAyuda.setText("Sin filas: todavia no hay respuestas de ese jugador en la categoria.");
        getContentPane().add(lblAyuda);
        lblAyuda.setBounds(25, 390, 610, 25);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
        try { tblRanking.setModel(Datos.ranking(sesion,Pantalla.id(cmbCategoria),chkMio.isSelected())); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnVerActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnVer;
    private javax.swing.JCheckBox chkMio;
    private javax.swing.JComboBox<Item> cmbCategoria;
    private javax.swing.JLabel lblAyuda;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JScrollPane scrolltblRanking;
    private javax.swing.JTable tblRanking;
    // End of variables declaration//GEN-END:variables
}
