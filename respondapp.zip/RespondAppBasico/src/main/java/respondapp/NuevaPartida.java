package respondapp;

import javax.swing.JOptionPane;

public class NuevaPartida extends javax.swing.JFrame {
    private Usuario sesion;

    public NuevaPartida(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion; lblJugador1.setText("Jugador 1: "+sesion.usuario); txtRondas.setText("10");
        try {
            Datos.jugador(sesion);
            for(Item i:Datos.jugadores()) if(i.id!=sesion.id) cmbJugador.addItem(i);
            for(Item i:Datos.pendientes(sesion)) cmbPendientes.addItem(i);
        } catch(Exception ex) { Pantalla.error(this,ex); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblJugador1 = new javax.swing.JLabel();
        lblJugador2 = new javax.swing.JLabel();
        cmbJugador = new javax.swing.JComboBox();
        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();
        lblRondas = new javax.swing.JLabel();
        txtRondas = new javax.swing.JTextField();
        btnCrear = new javax.swing.JButton();
        lblPendientes = new javax.swing.JLabel();
        cmbPendientes = new javax.swing.JComboBox();
        btnContinuar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        lblRegla = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Nueva partida o continuar");
        setResizable(false);
        setPreferredSize(new java.awt.Dimension(650, 460));
        getContentPane().setLayout(null);
        lblJugador1.setText("Jugador 1");
        getContentPane().add(lblJugador1);
        lblJugador1.setBounds(25, 20, 580, 25);
        lblJugador2.setText("Jugador 2");
        getContentPane().add(lblJugador2);
        lblJugador2.setBounds(25, 65, 160, 25);
        getContentPane().add(cmbJugador);
        cmbJugador.setBounds(190, 65, 390, 28);
        lblClave.setText("Clave del jugador 2");
        getContentPane().add(lblClave);
        lblClave.setBounds(25, 105, 160, 25);
        getContentPane().add(txtClave);
        txtClave.setBounds(190, 105, 390, 28);
        lblRondas.setText("Rondas (par, 2 a 20)");
        getContentPane().add(lblRondas);
        lblRondas.setBounds(25, 145, 160, 25);
        getContentPane().add(txtRondas);
        txtRondas.setBounds(190, 145, 390, 28);
        btnCrear.setText("Crear partida");
        btnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearActionPerformed(evt);
            }
        });
        getContentPane().add(btnCrear);
        btnCrear.setBounds(190, 190, 180, 32);
        lblPendientes.setText("Partidas en curso");
        getContentPane().add(lblPendientes);
        lblPendientes.setBounds(25, 245, 160, 25);
        getContentPane().add(cmbPendientes);
        cmbPendientes.setBounds(190, 245, 390, 28);
        btnContinuar.setText("Continuar partida");
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });
        getContentPane().add(btnContinuar);
        btnContinuar.setBounds(190, 290, 180, 32);
        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(390, 290, 160, 32);
        lblRegla.setText("Se alternan turnos. Acierto: 10 puntos. Error: 0 puntos.");
        getContentPane().add(lblRegla);
        lblRegla.setBounds(25, 345, 580, 25);
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
        char[] clave=txtClave.getPassword();
        try {
            int rondas;
            try { rondas=Integer.parseInt(txtRondas.getText().trim()); } catch(NumberFormatException ex) { throw new Exception("Escriba un numero par de rondas entre 2 y 20."); }
            int partida=Datos.nuevaPartida(sesion,Pantalla.id(cmbJugador),clave,rondas);
            Juego juego=new Juego(sesion); juego.abrir(partida); juego.setVisible(true); dispose();
        } catch(Exception ex) { Pantalla.error(this,ex); }
        finally { java.util.Arrays.fill(clave,'\0'); txtClave.setText(""); }
    }//GEN-LAST:event_btnCrearActionPerformed

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed
        try { Juego juego=new Juego(sesion); juego.abrir(Pantalla.id(cmbPendientes)); juego.setVisible(true); dispose(); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblJugador1;
    private javax.swing.JLabel lblJugador2;
    private javax.swing.JComboBox<Item> cmbJugador;
    private javax.swing.JLabel lblClave;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JLabel lblRondas;
    private javax.swing.JTextField txtRondas;
    private javax.swing.JButton btnCrear;
    private javax.swing.JLabel lblPendientes;
    private javax.swing.JComboBox<Item> cmbPendientes;
    private javax.swing.JButton btnContinuar;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JLabel lblRegla;
    // End of variables declaration//GEN-END:variables
}
