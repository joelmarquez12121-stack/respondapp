package respondapp;

import javax.swing.JOptionPane;

public class Perfil extends javax.swing.JFrame {
    private Usuario sesion;

    public Perfil(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        lblUsuario.setText("Usuario: "+sesion.usuario);
        txtNombre.setText(sesion.nombre); txtFecha.setText(sesion.nacimiento); txtEmail.setText(sesion.email);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblUsuario = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblFecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Mis datos");
        setResizable(false);
        setPreferredSize(new java.awt.Dimension(620, 330));
        getContentPane().setLayout(null);
        lblUsuario.setText("Usuario");
        getContentPane().add(lblUsuario);
        lblUsuario.setBounds(25, 25, 550, 25);
        lblNombre.setText("Nombre completo");
        getContentPane().add(lblNombre);
        lblNombre.setBounds(25, 70, 160, 25);
        getContentPane().add(txtNombre);
        txtNombre.setBounds(190, 70, 370, 28);
        lblFecha.setText("Nacimiento AAAA-MM-DD");
        getContentPane().add(lblFecha);
        lblFecha.setBounds(25, 115, 160, 25);
        getContentPane().add(txtFecha);
        txtFecha.setBounds(190, 115, 370, 28);
        lblEmail.setText("Email");
        getContentPane().add(lblEmail);
        lblEmail.setBounds(25, 160, 160, 25);
        getContentPane().add(txtEmail);
        txtEmail.setBounds(190, 160, 370, 28);
        btnGuardar.setText("Guardar cambios");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(190, 215, 175, 32);
        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(380, 215, 150, 32);
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try { Datos.perfil(sesion,txtNombre.getText(),txtFecha.getText(),txtEmail.getText()); JOptionPane.showMessageDialog(this,"Datos actualizados."); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnCerrar;
    // End of variables declaration//GEN-END:variables
}
